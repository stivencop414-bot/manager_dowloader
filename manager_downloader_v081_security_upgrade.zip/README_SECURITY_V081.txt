Manager Downloader v0.8.1 — Security + resume + throughput overlay

This ZIP intentionally contains NO executable scripts.
The GitHub workflow verifies the ZIP SHA-256, copies only reviewed text/source payload files,
and performs all textual patches from visible code embedded directly in the workflow.

Included payload:
- SecurityUrlPolicy.kt: HTTPS-only/public-network policy for automatic analyzers, bounded bodies, SSRF-resistant DNS.
- HlsManifestParser.kt: secure HLS manifest/variant handling with bounded responses.
- TorrentEngine.kt: process-wide libtorrent SessionManager to avoid rapid JNI stop/start races.
- YouTubeMultiRangeDownloader.kt: cooperative resumable multi-range track downloads without Future.cancel(true).
- proguard-rules.pro: release/R8 keep rules for native/extractor bindings.

Workflow behavior:
- creates a security-v0.8.1-* branch, never pushes source changes directly to main;
- removes legacy upgrade-v0*.yml workflows and binary upgrade ZIPs on the candidate branch;
- runs preflight, Debug compile and Release compile before pushing the candidate branch;
- opens a Pull Request for human review;
- does NOT publish a debug APK to Releases;
- does NOT force-push tags.
