#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path


def fail(message: str) -> None:
    raise SystemExit(f"v0.8.0 patch error: {message}")


def read(path: Path) -> str:
    if not path.is_file():
        fail(f"missing expected file: {path}")
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def replace_exact(root: Path, rel: str, old: str, new: str, count: int = 1) -> None:
    path = root / rel
    text = read(path)
    occurrences = text.count(old)
    if occurrences < count:
        fail(f"anchor not found in {rel}: expected >= {count}, got {occurrences}\nANCHOR:\n{old[:500]}")
    write(path, text.replace(old, new, count))
    print(f"PATCHED {rel}")


def replace_regex(root: Path, rel: str, pattern: str, replacement: str, count: int = 1, flags: int = 0) -> None:
    path = root / rel
    text = read(path)
    new_text, n = re.subn(pattern, replacement, text, count=count, flags=flags)
    if n != count:
        fail(f"regex anchor mismatch in {rel}: expected {count}, got {n}: {pattern}")
    write(path, new_text)
    print(f"PATCHED {rel}")


def prepend_once(root: Path, rel: str, marker: str, content: str) -> None:
    path = root / rel
    text = read(path)
    if marker in text:
        return
    write(path, content.rstrip() + "\n\n" + text)
    print(f"UPDATED {rel}")


def copy_payload(bundle: Path, root: Path) -> None:
    payload = bundle / "payload"
    if not payload.is_dir():
        fail("payload directory missing from upgrade ZIP")
    for source in payload.rglob("*"):
        if source.is_dir():
            continue
        rel = source.relative_to(payload)
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        print(f"ADDED {rel}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default=".")
    args = parser.parse_args()
    root = Path(args.repo).resolve()
    bundle = Path(__file__).resolve().parent

    # Hard base guard: this bundle is intentionally tied to the audited v0.7.5 layout.
    gradle = read(root / "app/build.gradle.kts")
    if '?: "0.7.5"' not in gradle:
        fail("this bundle requires the audited v0.7.5 base; refusing to patch another version")

    # ------------------------------------------------------------------
    # Version + 8 audited stability fixes
    # ------------------------------------------------------------------
    replace_exact(root, "app/build.gradle.kts", '?: "0.7.5"', '?: "0.8.0"')
    replace_exact(root, "app/src/main/AndroidManifest.xml", 'android:usesCleartextTraffic="false"', 'android:usesCleartextTraffic="true"')
    replace_exact(root, "app/src/main/res/xml/network_security_config.xml", 'cleartextTrafficPermitted="false"', 'cleartextTrafficPermitted="true"')

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/DownloadsScreen.kt",
        '''private fun normalizeUrl(value: String): String? {\n    val trimmed = value.trim()\n    if (trimmed.startsWith("magnet:", true)) return trimmed\n    val candidate = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {\n        trimmed\n    } else {\n        "https://$trimmed"\n    }\n    return candidate.takeIf { runCatching { java.net.URI(it).host != null }.getOrDefault(false) }\n}''',
        '''private fun normalizeUrl(value: String): String? {\n    val trimmed = value.trim()\n    if (trimmed.startsWith("magnet:", true)) return trimmed\n    val candidate = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {\n        trimmed\n    } else {\n        "https://$trimmed"\n    }\n    return candidate.takeIf {\n        runCatching {\n            val parsed = android.net.Uri.parse(it)\n            !parsed.host.isNullOrBlank() &&\n                (parsed.scheme.equals("http", true) || parsed.scheme.equals("https", true))\n        }.getOrDefault(false)\n    }\n}'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''                enqueueTorrent(uri.toString(), queryDisplayName(uri))''',
        '''                importTorrentUri(uri)?.let { (localUri, name) ->\n                    enqueueTorrent(localUri, name)\n                }'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''                    YouTubeUrlParser.parse(uri.toString()) != null -> incomingBrowserUrl = uri.toString()\n                }''',
        '''                    YouTubeUrlParser.parse(uri.toString()) != null -> incomingBrowserUrl = uri.toString()\n                    uri.scheme.equals("http", true) || uri.scheme.equals("https", true) ->\n                        incomingBrowserUrl = uri.toString()\n                }'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/StorageRepository.kt",
        '''                val size = source.length()\n                if (size > 0L) source.delete()\n                return target.uri.toString()''',
        '''                runCatching { source.delete() }\n                return target.uri.toString()'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/browser/ContentBlocker.kt",
        '''            if (line.startsWith("0.0.0.0 ") || line.startsWith("127.0.0.1 ")) {\n                val domain = line.substringAfter(' ').trim().substringBefore(' ').lowercase(Locale.US)\n                if (isDomain(domain)) add(domain)\n            }''',
        '''            val hostsParts = line.split(Regex("\\\\s+"), limit = 3)\n            if (hostsParts.size >= 2 && hostsParts[0] in setOf("0.0.0.0", "127.0.0.1")) {\n                val domain = hostsParts[1].trim().lowercase(Locale.US)\n                if (isDomain(domain)) add(domain)\n            }'''
    )
    replace_exact(root, "app/src/main/java/com/managerdownloader/app/browser/ContentBlocker.kt", 'ManagerDownloader/0.7.5', 'ManagerDownloader/0.8.0')

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''        if (dir.usableSpace in 1 until (remaining + reserve)) {''',
        '''        if (dir.usableSpace in 0 until (remaining + reserve)) {'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/TorrentEngine.kt",
        '''                val status = torrentHandle.status()\n                val total = status.totalWanted().takeIf { it > 0L }''',
        '''                if (!runCatching { torrentHandle.isValid }.getOrDefault(false)) return\n                val status = runCatching { torrentHandle.status() }.getOrNull() ?: return\n                val total = status.totalWanted().takeIf { it > 0L }'''
    )

    # ------------------------------------------------------------------
    # Download model: JIT YouTube batch items + native high-quality mux jobs.
    # Backward compatible: all new JSON fields are optional.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadModels.kt",
        '''enum class DownloadKind {\n    HTTP,\n    TORRENT\n}''',
        '''enum class DownloadKind {\n    HTTP,\n    TORRENT,\n    YOUTUBE_JIT,\n    YOUTUBE_MUXED\n}'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadModels.kt",
        '''    /** Extractor-specific format id/itag used to refresh an expired stream URL. */\n    val sourceFormatId: String? = null\n) {''',
        '''    /** Extractor-specific primary format id/itag used to refresh an expired stream URL. */\n    val sourceFormatId: String? = null,\n    /** Optional second stream used by native video+audio mux jobs. */\n    val secondaryUrl: String? = null,\n    val secondarySourceFormatId: String? = null,\n    /** mp4 or webm for native MediaMuxer jobs. */\n    val muxContainer: String? = null,\n    /** Logical JIT profile used for playlist/channel queue entries. */\n    val sourceProfile: String? = null\n) {'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadRepository.kt",
        '''        expectedSha256: String? = null,\n        originalSourceUrl: String? = null,\n        sourceFormatId: String? = null\n    ): DownloadTask {''',
        '''        expectedSha256: String? = null,\n        originalSourceUrl: String? = null,\n        sourceFormatId: String? = null,\n        secondaryUrl: String? = null,\n        secondarySourceFormatId: String? = null,\n        muxContainer: String? = null,\n        sourceProfile: String? = null\n    ): DownloadTask {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadRepository.kt",
        '''                originalSourceUrl = originalSourceUrl?.takeIf { it.isNotBlank() },\n                sourceFormatId = sourceFormatId?.takeIf { it.isNotBlank() }\n            ).also { newTask ->''',
        '''                originalSourceUrl = originalSourceUrl?.takeIf { it.isNotBlank() },\n                sourceFormatId = sourceFormatId?.takeIf { it.isNotBlank() },\n                secondaryUrl = secondaryUrl?.takeIf { it.isNotBlank() },\n                secondarySourceFormatId = secondarySourceFormatId?.takeIf { it.isNotBlank() },\n                muxContainer = muxContainer?.lowercase()?.takeIf { it == "mp4" || it == "webm" },\n                sourceProfile = sourceProfile?.takeIf { it.isNotBlank() }\n            ).also { newTask ->'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadRepository.kt",
        '''    fun updateHash(id: String, actualSha256: String) = update(id) { item ->''',
        '''    fun updateMuxUrls(\n        id: String,\n        videoUrl: String,\n        audioUrl: String,\n        videoFormatId: String?,\n        audioFormatId: String?,\n        container: String?,\n        filename: String? = null\n    ) = update(id) { item ->\n        item.copy(\n            url = videoUrl.trim(),\n            secondaryUrl = audioUrl.trim(),\n            sourceFormatId = videoFormatId ?: item.sourceFormatId,\n            secondarySourceFormatId = audioFormatId ?: item.secondarySourceFormatId,\n            muxContainer = container ?: item.muxContainer,\n            filename = filename?.takeIf { it.isNotBlank() }?.let(::sanitizeFilename) ?: item.filename,\n            error = null,\n            detail = "Enlaces HD renovados"\n        )\n    }\n\n    fun updateHash(id: String, actualSha256: String) = update(id) { item ->'''
    )

    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadRepository.kt",
        '''                put("originalSourceUrl", item.originalSourceUrl ?: JSONObject.NULL)\n                put("sourceFormatId", item.sourceFormatId ?: JSONObject.NULL)\n            })''',
        '''                put("originalSourceUrl", item.originalSourceUrl ?: JSONObject.NULL)\n                put("sourceFormatId", item.sourceFormatId ?: JSONObject.NULL)\n                put("secondaryUrl", item.secondaryUrl ?: JSONObject.NULL)\n                put("secondarySourceFormatId", item.secondarySourceFormatId ?: JSONObject.NULL)\n                put("muxContainer", item.muxContainer ?: JSONObject.NULL)\n                put("sourceProfile", item.sourceProfile ?: JSONObject.NULL)\n            })'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/data/DownloadRepository.kt",
        '''                            originalSourceUrl = obj.optNullableString("originalSourceUrl"),\n                            sourceFormatId = obj.optNullableString("sourceFormatId")\n                        )''',
        '''                            originalSourceUrl = obj.optNullableString("originalSourceUrl"),\n                            sourceFormatId = obj.optNullableString("sourceFormatId"),\n                            secondaryUrl = obj.optNullableString("secondaryUrl"),\n                            secondarySourceFormatId = obj.optNullableString("secondarySourceFormatId"),\n                            muxContainer = obj.optNullableString("muxContainer"),\n                            sourceProfile = obj.optNullableString("sourceProfile")\n                        )'''
    )

    # ------------------------------------------------------------------
    # YouTube extractor: pair video-only + compatible best audio for native muxing.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/youtube/YouTubeSupport.kt",
        '''data class YouTubeVideoDetails(\n    val sourceUrl: String,\n    val title: String,\n    val uploader: String,\n    val durationSeconds: Long,\n    val thumbnailUrl: String?,\n    val progressiveVideo: List<YouTubeFormatOption>,\n    val videoOnly: List<YouTubeFormatOption>,\n    val audioOnly: List<YouTubeFormatOption>,\n    val warnings: List<String>\n)''',
        '''data class YouTubeMuxedOption(\n    val id: String,\n    val label: String,\n    val videoUrl: String,\n    val audioUrl: String,\n    val filename: String,\n    val videoFormatId: String,\n    val audioFormatId: String,\n    val container: String,\n    val height: Int\n)\n\ndata class YouTubeVideoDetails(\n    val sourceUrl: String,\n    val title: String,\n    val uploader: String,\n    val durationSeconds: Long,\n    val thumbnailUrl: String?,\n    val progressiveVideo: List<YouTubeFormatOption>,\n    val videoOnly: List<YouTubeFormatOption>,\n    val audioOnly: List<YouTubeFormatOption>,\n    val muxedHighQuality: List<YouTubeMuxedOption>,\n    val warnings: List<String>\n)'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/youtube/YouTubeSupport.kt",
        '''    private fun ensureInitialized() {''',
        '''    internal fun ensureInitialized() {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/youtube/YouTubeSupport.kt",
        '''        val warnings = buildList {\n            if (progressive.isEmpty() && videoOnly.isNotEmpty()) {\n                add("Este video solo expone pistas separadas de video/audio; la fusión de alta calidad todavía no está habilitada.")\n            }''',
        '''        val muxed = buildMuxedOptions(videoOnly, audio, safeTitle)\n\n        val warnings = buildList {\n            if (progressive.isEmpty() && muxed.isEmpty() && videoOnly.isNotEmpty()) {\n                add("Este video expone pistas separadas, pero no se encontró una combinación compatible para MediaMuxer.")\n            }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/youtube/YouTubeSupport.kt",
        '''            progressiveVideo = progressive,\n            videoOnly = videoOnly,\n            audioOnly = audio,\n            warnings = warnings''',
        '''            progressiveVideo = progressive,\n            videoOnly = videoOnly,\n            audioOnly = audio,\n            muxedHighQuality = muxed,\n            warnings = warnings'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/youtube/YouTubeSupport.kt",
        '''    private fun sanitizeFileName(value: String): String = value''',
        '''    private fun buildMuxedOptions(\n        videoOnly: List<YouTubeFormatOption>,\n        audioOnly: List<YouTubeFormatOption>,\n        title: String\n    ): List<YouTubeMuxedOption> = videoOnly.mapNotNull { video ->\n        val container = when {\n            video.mimeType.contains("webm", true) || video.filename.endsWith(".webm", true) -> "webm"\n            video.mimeType.contains("mp4", true) || video.filename.endsWith(".mp4", true) || video.filename.endsWith(".m4v", true) -> "mp4"\n            else -> null\n        } ?: return@mapNotNull null\n\n        val audio = audioOnly.firstOrNull { candidate ->\n            when (container) {\n                "webm" -> candidate.mimeType.contains("webm", true) ||\n                    candidate.filename.endsWith(".webm", true) || candidate.filename.endsWith(".opus", true)\n                else -> candidate.mimeType.contains("mp4", true) ||\n                    candidate.filename.endsWith(".m4a", true) || candidate.filename.endsWith(".mp4", true)\n            }\n        } ?: return@mapNotNull null\n\n        YouTubeMuxedOption(\n            id = "${video.id}+${audio.id}",\n            label = buildString {\n                append(if (video.height > 0) "${video.height}p" else "Alta calidad")\n                append(" · ${container.uppercase(Locale.US)} · video + audio")\n            },\n            videoUrl = video.url,\n            audioUrl = audio.url,\n            filename = "$title.$container",\n            videoFormatId = video.id,\n            audioFormatId = audio.id,\n            container = container,\n            height = video.height\n        )\n    }.distinctBy { "${it.height}:${it.container}" }\n        .sortedByDescending { it.height }\n\n    private fun sanitizeFileName(value: String): String = value'''
    )

    # ------------------------------------------------------------------
    # Browser UI: high-quality mux jobs, playlist JIT batch, HLS rescan/analysis.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''import com.managerdownloader.app.data.SearchEngine\nimport com.managerdownloader.app.data.SettingsRepository''',
        '''import com.managerdownloader.app.data.DownloadKind\nimport com.managerdownloader.app.data.SearchEngine\nimport com.managerdownloader.app.data.SettingsRepository\nimport com.managerdownloader.app.hls.HlsManifestClient\nimport com.managerdownloader.app.hls.HlsVariantStream'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''import com.managerdownloader.app.youtube.YouTubeLink\nimport com.managerdownloader.app.youtube.YouTubeUrlParser\nimport com.managerdownloader.app.youtube.YouTubeVideoDetails''',
        '''import com.managerdownloader.app.youtube.YouTubeLink\nimport com.managerdownloader.app.youtube.YouTubePlaylistDetails\nimport com.managerdownloader.app.youtube.YouTubePlaylistExtractor\nimport com.managerdownloader.app.youtube.YouTubeUrlParser\nimport com.managerdownloader.app.youtube.YouTubeVideoDetails'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''data class BrowserDownloadRequest(\n    val url: String,\n    val filename: String?,\n    val cookie: String?,\n    val userAgent: String?,\n    val referer: String?,\n    val originalSourceUrl: String? = null,\n    val sourceFormatId: String? = null\n)''',
        '''data class BrowserDownloadRequest(\n    val url: String,\n    val filename: String?,\n    val cookie: String?,\n    val userAgent: String?,\n    val referer: String?,\n    val originalSourceUrl: String? = null,\n    val sourceFormatId: String? = null,\n    val kind: DownloadKind? = null,\n    val secondaryUrl: String? = null,\n    val secondarySourceFormatId: String? = null,\n    val muxContainer: String? = null,\n    val sourceProfile: String? = null\n)'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''    var youtubeDetails by remember { mutableStateOf<YouTubeVideoDetails?>(null) }\n    var youtubeError by remember { mutableStateOf<String?>(null) }''',
        '''    var youtubeDetails by remember { mutableStateOf<YouTubeVideoDetails?>(null) }\n    var youtubePlaylistDetails by remember { mutableStateOf<YouTubePlaylistDetails?>(null) }\n    val selectedPlaylistUrls = remember { mutableStateListOf<String>() }\n    var streamVariants by remember { mutableStateOf<List<HlsVariantStream>>(emptyList()) }\n    var streamAnalyzedUrl by remember { mutableStateOf<String?>(null) }\n    var streamLoading by remember { mutableStateOf(false) }\n    var streamError by remember { mutableStateOf<String?>(null) }\n    var youtubeError by remember { mutableStateOf<String?>(null) }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''    fun analyzeYouTube(link: YouTubeLink) {\n        if (!link.isVideo) {\n            youtubeError = "Se detectó una playlist, pero esta versión analiza videos individuales."\n            showYouTubeDialog = true\n            return\n        }\n        youtubeLoading = true\n        youtubeError = null\n        youtubeDetails = null\n        showYouTubeDialog = true\n        scope.launch {\n            val result = YouTubeExtractorClient.analyze(link.canonicalUrl ?: link.rawUrl)\n            youtubeLoading = false\n            result.onSuccess { youtubeDetails = it }\n                .onFailure { error ->\n                    youtubeError = error.message ?: error.javaClass.simpleName\n                }\n        }\n    }''',
        '''    fun analyzeYouTube(link: YouTubeLink) {\n        youtubeLoading = true\n        youtubeError = null\n        youtubeDetails = null\n        youtubePlaylistDetails = null\n        selectedPlaylistUrls.clear()\n        showYouTubeDialog = true\n        scope.launch {\n            if (link.isVideo) {\n                val result = YouTubeExtractorClient.analyze(link.canonicalUrl ?: link.rawUrl)\n                youtubeLoading = false\n                result.onSuccess { youtubeDetails = it }\n                    .onFailure { error -> youtubeError = error.message ?: error.javaClass.simpleName }\n            } else if (link.playlistId != null) {\n                val result = YouTubePlaylistExtractor.analyze(link.rawUrl)\n                youtubeLoading = false\n                result.onSuccess { youtubePlaylistDetails = it }\n                    .onFailure { error -> youtubeError = error.message ?: error.javaClass.simpleName }\n            } else {\n                youtubeLoading = false\n                youtubeError = "El enlace de YouTube no contiene un video o playlist compatible."\n            }\n        }\n    }\n\n    fun analyzeStream(item: DetectedDownload) {\n        if (item.kind != DetectedMediaKind.STREAM || !item.url.contains(".m3u8", true)) return\n        streamLoading = true\n        streamError = null\n        streamVariants = emptyList()\n        streamAnalyzedUrl = item.url\n        scope.launch {\n            val result = HlsManifestClient.analyze(item.url, item.cookie, item.userAgent, item.referer)\n            streamLoading = false\n            result.onSuccess { streamVariants = it }\n                .onFailure { error -> streamError = error.message ?: error.javaClass.simpleName }\n        }\n    }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''            youtubeDetails = null\n            youtubeError = null\n            showYouTubeDialog = false''',
        '''            youtubeDetails = null\n            youtubePlaylistDetails = null\n            selectedPlaylistUrls.clear()\n            youtubeError = null\n            showYouTubeDialog = false'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                FloatingActionButton(\n                    onClick = { showMediaDetected = true },''',
        '''                FloatingActionButton(\n                    onClick = {\n                        triggerActiveQualityRescan(webView)\n                        showMediaDetected = true\n                    },'''
    )

    # High-quality section replaces the old "video only, cannot download" explanation.
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                        if (details.videoOnly.isNotEmpty()) {\n                            HorizontalDivider()\n                            Text("Calidad alta separada", style = MaterialTheme.typography.titleSmall)\n                            Text(\n                                "Se detectaron ${details.videoOnly.size} pistas de video sin audio. No se descargan como video final todavía porque requieren fusionar una pista de audio compatible.",\n                                style = MaterialTheme.typography.bodySmall,\n                                color = MaterialTheme.colorScheme.onSurfaceVariant\n                            )\n                            details.videoOnly.take(4).forEach { Text("• ${it.label}", style = MaterialTheme.typography.bodySmall) }\n                        }''',
        '''                        if (details.muxedHighQuality.isNotEmpty()) {\n                            HorizontalDivider()\n                            Text("Alta calidad fusionada", style = MaterialTheme.typography.titleSmall)\n                            Text(\n                                "Descarga video y audio por separado y los fusiona localmente con MediaMuxer, sin recodificar.",\n                                style = MaterialTheme.typography.bodySmall,\n                                color = MaterialTheme.colorScheme.onSurfaceVariant\n                            )\n                            details.muxedHighQuality.take(8).forEach { option ->\n                                OutlinedButton(\n                                    modifier = Modifier.fillMaxWidth(),\n                                    onClick = {\n                                        val cookie = CookieManager.getInstance().getCookie(details.sourceUrl)\n                                        onAddBatch(\n                                            listOf(\n                                                BrowserDownloadRequest(\n                                                    url = option.videoUrl,\n                                                    filename = option.filename,\n                                                    cookie = cookie,\n                                                    userAgent = runCatching { webView?.settings?.userAgentString }.getOrNull(),\n                                                    referer = details.sourceUrl,\n                                                    originalSourceUrl = details.sourceUrl,\n                                                    sourceFormatId = option.videoFormatId,\n                                                    kind = DownloadKind.YOUTUBE_MUXED,\n                                                    secondaryUrl = option.audioUrl,\n                                                    secondarySourceFormatId = option.audioFormatId,\n                                                    muxContainer = option.container\n                                                )\n                                            )\n                                        )\n                                        showYouTubeDialog = false\n                                    }\n                                ) { Text("Descargar ${option.label}") }\n                            }\n                        } else if (details.videoOnly.isNotEmpty()) {\n                            HorizontalDivider()\n                            Text("Calidad alta separada", style = MaterialTheme.typography.titleSmall)\n                            Text(\n                                "Hay pistas separadas, pero ninguna pareja es compatible con el muxer nativo del dispositivo.",\n                                style = MaterialTheme.typography.bodySmall,\n                                color = MaterialTheme.colorScheme.onSurfaceVariant\n                            )\n                        }'''
    )

    # Insert playlist UI just after video details block and before legal note container closes.
    playlist_anchor = '''                    youtubeDetails?.let { details ->'''
    # We append playlist UI after the full youtubeDetails let by targeting the legal-note tail.
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                        Text(\n                            "Úsalo únicamente con contenido que tengas permiso para descargar. No se intenta eludir DRM, contenido privado ni controles de acceso.",\n                            style = MaterialTheme.typography.bodySmall,\n                            color = MaterialTheme.colorScheme.onSurfaceVariant\n                        )\n                    }\n                }''',
        '''                        Text(\n                            "Úsalo únicamente con contenido que tengas permiso para descargar. No se intenta eludir DRM, contenido privado ni controles de acceso.",\n                            style = MaterialTheme.typography.bodySmall,\n                            color = MaterialTheme.colorScheme.onSurfaceVariant\n                        )\n                    }\n\n                    youtubePlaylistDetails?.let { playlist ->\n                        Text(playlist.title, style = MaterialTheme.typography.titleMedium)\n                        if (playlist.author.isNotBlank()) Text(playlist.author, style = MaterialTheme.typography.bodySmall)\n                        Text(\n                            "${playlist.items.size} videos${if (playlist.truncated) " · límite de 200 por análisis" else ""}. Los enlaces directos se resuelven justo cuando cada video obtiene turno para reducir 403/429.",\n                            style = MaterialTheme.typography.bodySmall,\n                            color = MaterialTheme.colorScheme.onSurfaceVariant\n                        )\n                        Row(verticalAlignment = Alignment.CenterVertically) {\n                            val allSelected = playlist.items.isNotEmpty() && playlist.items.all { it.canonicalUrl in selectedPlaylistUrls }\n                            Checkbox(\n                                checked = allSelected,\n                                onCheckedChange = { checked ->\n                                    selectedPlaylistUrls.clear()\n                                    if (checked) selectedPlaylistUrls.addAll(playlist.items.map { it.canonicalUrl })\n                                }\n                            )\n                            Text(if (allSelected) "Deseleccionar todo" else "Seleccionar todo")\n                        }\n                        Column(\n                            modifier = Modifier.height(280.dp).verticalScroll(rememberScrollState()),\n                            verticalArrangement = Arrangement.spacedBy(4.dp)\n                        ) {\n                            playlist.items.forEach { item ->\n                                Row(verticalAlignment = Alignment.CenterVertically) {\n                                    Checkbox(\n                                        checked = item.canonicalUrl in selectedPlaylistUrls,\n                                        onCheckedChange = { checked ->\n                                            if (checked && item.canonicalUrl !in selectedPlaylistUrls) selectedPlaylistUrls.add(item.canonicalUrl)\n                                            if (!checked) selectedPlaylistUrls.remove(item.canonicalUrl)\n                                        }\n                                    )\n                                    Column(Modifier.weight(1f)) {\n                                        Text("${item.position}. ${item.title}", maxLines = 2)\n                                        if (item.uploader.isNotBlank()) Text(item.uploader, style = MaterialTheme.typography.bodySmall)\n                                    }\n                                }\n                            }\n                        }\n                        Button(\n                            modifier = Modifier.fillMaxWidth(),\n                            enabled = selectedPlaylistUrls.isNotEmpty(),\n                            onClick = {\n                                val selected = selectedPlaylistUrls.toSet()\n                                val userAgent = runCatching { webView?.settings?.userAgentString }.getOrNull()\n                                val requests = playlist.items.filter { it.canonicalUrl in selected }.map { item ->\n                                    BrowserDownloadRequest(\n                                        url = item.canonicalUrl,\n                                        filename = "${item.title}.mp4",\n                                        cookie = null,\n                                        userAgent = userAgent,\n                                        referer = item.canonicalUrl,\n                                        originalSourceUrl = item.canonicalUrl,\n                                        kind = DownloadKind.YOUTUBE_JIT,\n                                        sourceProfile = "best_progressive"\n                                    )\n                                }\n                                onAddBatch(requests)\n                                selectedPlaylistUrls.clear()\n                                showYouTubeDialog = false\n                            }\n                        ) { Text("Añadir selección a la cola") }\n                    }\n                }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                if (youtubeDetails == null && !youtubeLoading && link.isVideo) {\n                    Button(onClick = { analyzeYouTube(link) }) { Text("Analizar") }''',
        '''                if (youtubeDetails == null && youtubePlaylistDetails == null && !youtubeLoading) {\n                    Button(onClick = { analyzeYouTube(link) }) { Text("Analizar") }'''
    )

    # HLS analysis details and action.
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                    if (!item.downloadable) {\n                        Text(\n                            if (item.kind == DetectedMediaKind.STREAM) {\n                                "Es un manifiesto HLS/DASH, no un archivo de video completo. Se detecta para análisis, pero no se guarda como .txt ni se añade al motor HTTP directo."''',
        '''                    if (!item.downloadable) {\n                        Text(\n                            if (item.kind == DetectedMediaKind.STREAM) {\n                                "Es un manifiesto HLS/DASH, no un archivo de video completo. El detector puede analizar un HLS Master y mostrar sus variantes sin guardar el manifiesto como .txt."'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''                            color = MaterialTheme.colorScheme.onSurfaceVariant\n                        )\n                    }\n                }\n            },\n            confirmButton = {\n                if (item.downloadable) {''',
        '''                            color = MaterialTheme.colorScheme.onSurfaceVariant\n                        )\n                        if (item.kind == DetectedMediaKind.STREAM && streamAnalyzedUrl == item.url) {\n                            if (streamLoading) {\n                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {\n                                    CircularProgressIndicator()\n                                    Text("Analizando manifiesto…")\n                                }\n                            }\n                            streamError?.let { Text(it, color = MaterialTheme.colorScheme.error) }\n                            streamVariants.take(12).forEach { variant ->\n                                Text(\n                                    "• ${variant.qualityLabel} · ${variant.bandwidth / 1000} kbps${variant.codecs?.let { " · $it" } ?: ""}",\n                                    style = MaterialTheme.typography.bodySmall\n                                )\n                            }\n                            if (!streamLoading && streamError == null && streamVariants.isEmpty()) {\n                                Text("El HLS no expone variantes Master; puede ser una playlist de medios directa.", style = MaterialTheme.typography.bodySmall)\n                            }\n                        }\n                    }\n                }\n            },\n            confirmButton = {\n                if (item.kind == DetectedMediaKind.STREAM && item.url.contains(".m3u8", true)) {\n                    Button(\n                        enabled = !streamLoading,\n                        onClick = { analyzeStream(item) }\n                    ) { Text(if (streamAnalyzedUrl == item.url) "Reanalizar calidades" else "Analizar calidades") }\n                } else if (item.downloadable) {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''            dismissButton = {\n                if (item.downloadable) {\n                    TextButton(onClick = { detected = null }) { Text("Cancelar") }\n                }\n            }''',
        '''            dismissButton = {\n                if (item.downloadable) {\n                    TextButton(onClick = { detected = null }) { Text("Cancelar") }\n                } else if (item.kind == DetectedMediaKind.STREAM) {\n                    TextButton(onClick = { detected = null }) { Text("Cerrar") }\n                }\n            }'''
    )

    # Reactive fetch/XHR HLS discovery. Inject after report() so it can reuse the bounded bridge.
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''    function inspectElement(el) {''',
        '''    const streamRx = /\\.(m3u8|mpd)(?:$|[?#])/i;\n    const originalFetch = window.fetch;\n    const originalXhrOpen = XMLHttpRequest.prototype.open;\n\n    if (originalFetch) {\n      window.fetch = function(...args) {\n        try {\n          const candidate = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');\n          if (candidate && streamRx.test(candidate)) report(candidate, 'stream_fetch');\n        } catch (_) {}\n        return originalFetch.apply(this, args);\n      };\n    }\n\n    XMLHttpRequest.prototype.open = function(method, url, ...rest) {\n      try { if (url && streamRx.test(String(url))) report(String(url), 'stream_xhr'); } catch (_) {}\n      return originalXhrOpen.call(this, method, url, ...rest);\n    };\n\n    window.__rescanActivePlayerQualities = function() {\n      try {\n        document.querySelectorAll('video,audio,source').forEach(function(el) {\n          report(el.currentSrc || el.src || el.getAttribute('src'), 'active_player');\n        });\n        if (window.videojs && window.videojs.getAllPlayers) {\n          window.videojs.getAllPlayers().forEach(function(player) {\n            try { report(player.currentSrc(), 'videojs'); } catch (_) {}\n          });\n        }\n      } catch (_) {}\n    };\n\n    function inspectElement(el) {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''    const timer = setTimeout(function() {\n      try { observer.disconnect(); } catch (_) {}\n      try { if (URL.createObjectURL === patchedCreate) URL.createObjectURL = originalCreate; } catch (_) {}\n    }, 15000);''',
        '''    const timer = setTimeout(function() {\n      try { observer.disconnect(); } catch (_) {}\n      try { if (URL.createObjectURL === patchedCreate) URL.createObjectURL = originalCreate; } catch (_) {}\n      try { if (originalFetch && window.fetch !== originalFetch) window.fetch = originalFetch; } catch (_) {}\n      try { if (XMLHttpRequest.prototype.open !== originalXhrOpen) XMLHttpRequest.prototype.open = originalXhrOpen; } catch (_) {}\n    }, 15000);'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''      try { if (URL.createObjectURL === patchedCreate) URL.createObjectURL = originalCreate; } catch (_) {}\n    };''',
        '''      try { if (URL.createObjectURL === patchedCreate) URL.createObjectURL = originalCreate; } catch (_) {}\n      try { if (originalFetch && window.fetch !== originalFetch) window.fetch = originalFetch; } catch (_) {}\n      try { if (XMLHttpRequest.prototype.open !== originalXhrOpen) XMLHttpRequest.prototype.open = originalXhrOpen; } catch (_) {}\n      try { delete window.__rescanActivePlayerQualities; } catch (_) {}\n    };'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/BrowserScreen.kt",
        '''private fun installBoundedMediaSniffer(view: WebView) {\n    if (!view.isAttachedToWindow) return\n    runCatching { view.evaluateJavascript(MEDIA_SNIFFER_SCRIPT, null) }\n}\n''',
        '''private fun installBoundedMediaSniffer(view: WebView) {\n    if (!view.isAttachedToWindow) return\n    runCatching { view.evaluateJavascript(MEDIA_SNIFFER_SCRIPT, null) }\n}\n\nprivate fun triggerActiveQualityRescan(view: WebView?) {\n    if (view == null || !view.isAttachedToWindow) return\n    runCatching { view.evaluateJavascript("window.__rescanActivePlayerQualities && window.__rescanActivePlayerQualities();", null) }\n}\n'''
    )

    # ------------------------------------------------------------------
    # ManagerDownloaderApp: pass rich batch metadata + foreground clipboard dialog.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/ManagerDownloaderApp.kt",
        '''    onMoveCompleted: (String) -> Unit,\n    incomingBrowserUrl: String? = null,\n    onIncomingBrowserUrlConsumed: () -> Unit = {}\n) {''',
        '''    onMoveCompleted: (String) -> Unit,\n    incomingBrowserUrl: String? = null,\n    onIncomingBrowserUrlConsumed: () -> Unit = {},\n    clipboardCandidate: String? = null,\n    onClipboardAccept: (String) -> Unit = {},\n    onClipboardDismiss: (String) -> Unit = {}\n) {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/ManagerDownloaderApp.kt",
        '''        if (showStoragePrompt && selectedTree == null) {\n            AlertDialog(''',
        '''        clipboardCandidate?.let { candidate ->\n            AlertDialog(\n                onDismissRequest = { onClipboardDismiss(candidate) },\n                title = { Text("Enlace detectado en el portapapeles") },\n                text = { Text(candidate, maxLines = 5) },\n                confirmButton = {\n                    Button(onClick = { onClipboardAccept(candidate) }) { Text("Abrir en Manager") }\n                },\n                dismissButton = {\n                    androidx.compose.material3.TextButton(onClick = { onClipboardDismiss(candidate) }) { Text("Ignorar") }\n                }\n            )\n        }\n\n        if (showStoragePrompt && selectedTree == null) {\n            AlertDialog('''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/ManagerDownloaderApp.kt",
        '''            sourceFormatId = request.sourceFormatId\n        )''',
        '''            sourceFormatId = request.sourceFormatId,\n            kind = request.kind,\n            secondaryUrl = request.secondaryUrl,\n            secondarySourceFormatId = request.secondarySourceFormatId,\n            muxContainer = request.muxContainer,\n            sourceProfile = request.sourceProfile\n        )'''
    )

    # ------------------------------------------------------------------
    # MainActivity: safe torrent import, generic HTTP VIEW, foreground clipboard checks/dialog.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''import com.managerdownloader.app.data.DownloadKind''',
        '''import com.managerdownloader.app.clipboard.ClipboardMonitor\nimport com.managerdownloader.app.data.DownloadKind'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''    private var incomingBrowserUrl by mutableStateOf<String?>(null)''',
        '''    private var incomingBrowserUrl by mutableStateOf<String?>(null)\n    private var clipboardCandidate by mutableStateOf<String?>(null)\n    private lateinit var clipboardMonitor: ClipboardMonitor'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''        handleIncomingIntent(intent)\n\n        setContent {''',
        '''        clipboardMonitor = ClipboardMonitor(this) { candidate -> clipboardCandidate = candidate }\n        handleIncomingIntent(intent)\n\n        setContent {'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''                incomingBrowserUrl = incomingBrowserUrl,\n                onIncomingBrowserUrlConsumed = { incomingBrowserUrl = null }\n            )''',
        '''                incomingBrowserUrl = incomingBrowserUrl,\n                onIncomingBrowserUrlConsumed = { incomingBrowserUrl = null },\n                clipboardCandidate = clipboardCandidate,\n                onClipboardAccept = { value ->\n                    clipboardCandidate = null\n                    incomingBrowserUrl = value\n                },\n                onClipboardDismiss = { value ->\n                    clipboardMonitor.dismiss(value)\n                    clipboardCandidate = null\n                }\n            )'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/MainActivity.kt",
        '''    override fun onNewIntent(intent: Intent) {''',
        '''    override fun onResume() {\n        super.onResume()\n        if (::clipboardMonitor.isInitialized) clipboardMonitor.checkClipboard()\n    }\n\n    override fun onWindowFocusChanged(hasFocus: Boolean) {\n        super.onWindowFocusChanged(hasFocus)\n        if (hasFocus && ::clipboardMonitor.isInitialized) clipboardMonitor.checkClipboard()\n    }\n\n    override fun onNewIntent(intent: Intent) {'''
    )

    # ------------------------------------------------------------------
    # DownloadService: JIT playlist resolver + staged native muxer.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''import com.managerdownloader.app.data.StorageRepository\nimport com.managerdownloader.app.youtube.YouTubeExtractorClient''',
        '''import com.managerdownloader.app.data.StorageRepository\nimport com.managerdownloader.app.media.NativeMediaMuxerEngine\nimport com.managerdownloader.app.youtube.YouTubeExtractorClient'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''                    DownloadRepository.markActive(\n                        task.id,\n                        if (task.kind == DownloadKind.TORRENT) "Preparando torrent…" else "Analizando servidor…"\n                    )''',
        '''                    DownloadRepository.markActive(\n                        task.id,\n                        when (task.kind) {\n                            DownloadKind.TORRENT -> "Preparando torrent…"\n                            DownloadKind.YOUTUBE_JIT -> "Resolviendo YouTube justo a tiempo…"\n                            DownloadKind.YOUTUBE_MUXED -> "Preparando video HD + audio…"\n                            DownloadKind.HTTP -> "Analizando servidor…"\n                        }\n                    )'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''                            when (task.kind) {\n                                DownloadKind.HTTP -> downloadHttp(task, control)\n                                DownloadKind.TORRENT -> torrentEngine.download(task, control, limit)\n                            }''',
        '''                            when (task.kind) {\n                                DownloadKind.HTTP -> downloadHttp(task, control)\n                                DownloadKind.TORRENT -> torrentEngine.download(task, control, limit)\n                                DownloadKind.YOUTUBE_JIT -> downloadYouTubeJit(task, control)\n                                DownloadKind.YOUTUBE_MUXED -> downloadYouTubeMuxed(task, control)\n                            }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''                if (\n                    error.statusCode == 403 &&\n                    !refreshedTemporaryUrl &&\n                    refreshExpiredExtractedStream(task)\n                ) {\n                    refreshedTemporaryUrl = true\n                    task = DownloadRepository.find(task.id) ?: task\n                    DownloadRepository.updateMetadata(task.id, detail = "Enlace temporal renovado · reanudando")\n                    continue\n                }''',
        '''                val refreshed = if (error.statusCode == 403 && !refreshedTemporaryUrl) {\n                    refreshExpiredExtractedStream(task)\n                } else null\n                if (refreshed != null) {\n                    refreshedTemporaryUrl = true\n                    task = refreshed\n                    DownloadRepository.updateMetadata(task.id, detail = "Enlace temporal renovado · reanudando")\n                    continue\n                }'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''    private fun refreshExpiredExtractedStream(task: DownloadTask): Boolean {\n        val sourceUrl = task.originalSourceUrl?.takeIf { it.isNotBlank() } ?: return false\n        val details = runBlocking { YouTubeExtractorClient.analyze(sourceUrl) }.getOrNull() ?: return false\n        val options = details.progressiveVideo + details.audioOnly + details.videoOnly\n        if (options.isEmpty()) return false\n\n        val selected = task.sourceFormatId?.let { wantedId ->\n            options.firstOrNull { it.id == wantedId }\n        } ?: run {\n            val ext = task.filename.substringAfterLast('.', "").lowercase()\n            options.firstOrNull { it.filename.substringAfterLast('.', "").equals(ext, true) }\n        } ?: return false\n\n        DownloadRepository.updateUrl(\n            id = task.id,\n            url = selected.url,\n            cookie = task.cookie,\n            userAgent = task.userAgent,\n            referer = sourceUrl\n        )\n        return true\n    }''',
        '''    private fun refreshExpiredExtractedStream(task: DownloadTask): DownloadTask? {\n        val sourceUrl = task.originalSourceUrl?.takeIf { it.isNotBlank() } ?: return null\n        val details = runBlocking { YouTubeExtractorClient.analyze(sourceUrl) }.getOrNull() ?: return null\n        val options = details.progressiveVideo + details.audioOnly + details.videoOnly\n        if (options.isEmpty()) return null\n\n        val selected = task.sourceFormatId?.let { wantedId ->\n            options.firstOrNull { it.id == wantedId }\n        } ?: run {\n            val ext = task.filename.substringAfterLast('.', "").lowercase()\n            options.firstOrNull { it.filename.substringAfterLast('.', "").equals(ext, true) }\n        } ?: return null\n\n        DownloadRepository.updateUrl(\n            id = task.id,\n            url = selected.url,\n            cookie = task.cookie,\n            userAgent = task.userAgent,\n            referer = sourceUrl\n        )\n        return task.copy(url = selected.url, sourceFormatId = selected.id, referer = sourceUrl)\n    }\n\n    private fun downloadYouTubeJit(task: DownloadTask, control: TransferControl) {\n        val sourceUrl = task.originalSourceUrl?.takeIf { it.isNotBlank() } ?: task.url\n        val details = runBlocking { YouTubeExtractorClient.analyze(sourceUrl) }\n            .getOrElse { throw IOException(it.message ?: "No se pudo analizar YouTube") }\n        if (control.stopped.get()) return\n\n        val profile = task.sourceProfile ?: "best_progressive"\n        val selected = when (profile) {\n            "best_audio" -> details.audioOnly.firstOrNull()\n            else -> details.progressiveVideo.firstOrNull()\n        }\n\n        if (selected != null) {\n            DownloadRepository.updateMetadata(task.id, filename = selected.filename, detail = "YouTube JIT · formato resuelto")\n            downloadHttp(\n                task.copy(\n                    url = selected.url,\n                    filename = selected.filename,\n                    kind = DownloadKind.HTTP,\n                    originalSourceUrl = sourceUrl,\n                    sourceFormatId = selected.id,\n                    referer = sourceUrl\n                ),\n                control\n            )\n            return\n        }\n\n        val muxed = details.muxedHighQuality.firstOrNull()\n            ?: throw IOException("YouTube no expuso un formato descargable compatible")\n        downloadYouTubeMuxed(\n            task.copy(\n                kind = DownloadKind.YOUTUBE_MUXED,\n                url = muxed.videoUrl,\n                secondaryUrl = muxed.audioUrl,\n                filename = muxed.filename,\n                sourceFormatId = muxed.videoFormatId,\n                secondarySourceFormatId = muxed.audioFormatId,\n                muxContainer = muxed.container,\n                originalSourceUrl = sourceUrl,\n                referer = sourceUrl\n            ),\n            control\n        )\n    }\n\n    private fun refreshMuxedTask(task: DownloadTask): DownloadTask? {\n        val sourceUrl = task.originalSourceUrl?.takeIf { it.isNotBlank() } ?: return null\n        val details = runBlocking { YouTubeExtractorClient.analyze(sourceUrl) }.getOrNull() ?: return null\n        val selected = details.muxedHighQuality.firstOrNull { option ->\n            option.videoFormatId == task.sourceFormatId &&\n                option.audioFormatId == task.secondarySourceFormatId\n        } ?: return null\n\n        DownloadRepository.updateMuxUrls(\n            id = task.id,\n            videoUrl = selected.videoUrl,\n            audioUrl = selected.audioUrl,\n            videoFormatId = selected.videoFormatId,\n            audioFormatId = selected.audioFormatId,\n            container = selected.container,\n            filename = selected.filename\n        )\n        return task.copy(\n            url = selected.videoUrl,\n            secondaryUrl = selected.audioUrl,\n            sourceFormatId = selected.videoFormatId,\n            secondarySourceFormatId = selected.audioFormatId,\n            muxContainer = selected.container,\n            filename = selected.filename,\n            referer = sourceUrl\n        )\n    }\n\n    private fun downloadYouTubeMuxed(initialTask: DownloadTask, control: TransferControl) {\n        var task = refreshMuxedTask(initialTask) ?: initialTask\n        val audioUrlInitial = task.secondaryUrl?.takeIf { it.isNotBlank() }\n            ?: throw IOException("Falta la pista de audio para fusionar")\n        val container = task.muxContainer?.lowercase()?.takeIf { it == "mp4" || it == "webm" } ?: "mp4"\n        val videoPart = youtubeVideoFile(task.id)\n        val audioPart = youtubeAudioFile(task.id)\n        val muxPart = youtubeMuxFile(task.id, container)\n\n        DownloadRepository.updateMetadata(task.id, filename = task.filename, detail = "YouTube HD · descargando video")\n        try {\n            downloadStagingStream(task, task.url, videoPart, control, "Video HD")\n        } catch (error: HttpStatusException) {\n            if (error.statusCode != 403 || control.stopped.get()) throw error\n            task = refreshMuxedTask(task) ?: throw error\n            downloadStagingStream(task, task.url, videoPart, control, "Video HD")\n        }\n        if (control.stopped.get()) return\n\n        task = refreshMuxedTask(task) ?: task\n        val audioUrl = task.secondaryUrl?.takeIf { it.isNotBlank() } ?: audioUrlInitial\n        DownloadRepository.updateMetadata(task.id, detail = "YouTube HD · descargando audio")\n        try {\n            downloadStagingStream(task, audioUrl, audioPart, control, "Audio")\n        } catch (error: HttpStatusException) {\n            if (error.statusCode != 403 || control.stopped.get()) throw error\n            task = refreshMuxedTask(task) ?: throw error\n            downloadStagingStream(task, task.secondaryUrl ?: audioUrl, audioPart, control, "Audio")\n        }\n        if (control.stopped.get()) return\n\n        val stagingBytes = videoPart.length() + audioPart.length()\n        DownloadRepository.updateMetadata(task.id, detail = "Fusionando video + audio · ${container.uppercase()}")\n        val muxResult = NativeMediaMuxerEngine.mux(\n            videoFile = videoPart,\n            audioFile = audioPart,\n            outputFile = muxPart,\n            container = container,\n            shouldStop = { control.stopped.get() },\n            onProgress = { fraction ->\n                DownloadRepository.updateProgress(\n                    task.id,\n                    (stagingBytes * fraction).toLong(),\n                    stagingBytes.coerceAtLeast(1L),\n                    0L,\n                    "Fusionando · ${(fraction * 100).toInt()}%"\n                )\n            }\n        )\n        if (muxResult.isFailure) {\n            runCatching { muxPart.delete() }\n            if (control.stopped.get()) return\n            throw IOException(muxResult.exceptionOrNull()?.message ?: "Falló la fusión de audio y video")\n        }\n\n        val finalName = DownloadRepository.find(task.id)?.filename ?: task.filename\n        val completedBytes = muxPart.length()\n        val publishedPath = StorageRepository.publishFile(muxPart, finalName, downloadsDirectory())\n        runCatching { videoPart.delete() }\n        runCatching { audioPart.delete() }\n        DownloadRepository.markCompleted(task.id, publishedPath, completedBytes)\n        showCompletedNotification(finalName)\n    }\n\n    private fun downloadStagingStream(\n        task: DownloadTask,\n        url: String,\n        target: File,\n        control: TransferControl,\n        label: String\n    ) {\n        target.parentFile?.mkdirs()\n        var existing = target.length().coerceAtLeast(0L)\n        val builder = Request.Builder().url(url).header("Accept-Encoding", "identity").get()\n        task.cookie?.takeIf { it.isNotBlank() }?.let { builder.header("Cookie", it) }\n        task.userAgent?.takeIf { it.isNotBlank() }?.let { builder.header("User-Agent", it) }\n        task.referer?.takeIf { it.isNotBlank() }?.let { builder.header("Referer", it) }\n        if (existing > 0L) builder.header("Range", "bytes=$existing-")\n\n        val call = client.newCall(builder.build())\n        control.calls.add(call)\n        try {\n            call.execute().use { response ->\n                if (!response.isSuccessful) throw HttpStatusException(response.code, "HTTP ${response.code} al descargar $label")\n                if (existing > 0L && response.code == 200) {\n                    RandomAccessFile(target, "rw").use { it.setLength(0L) }\n                    existing = 0L\n                } else if (existing > 0L && response.code == 206) {\n                    val range = parseContentRange(response.header("Content-Range"))\n                        ?: throw IOException("Content-Range inválido al reanudar $label")\n                    if (range.start != existing) throw IOException("$label reanudó desde ${range.start}, se esperaba $existing")\n                }\n\n                val body = response.body ?: throw IOException("Respuesta vacía al descargar $label")\n                val total = parseContentRange(response.header("Content-Range"))?.total\n                    ?: body.contentLength().takeIf { it > 0L }?.plus(existing)\n                    ?: -1L\n                if (total > 0L) ensureStagingSpace(target, total)\n                var downloaded = existing\n                var lastBytes = downloaded\n                var lastTime = System.currentTimeMillis()\n\n                RandomAccessFile(target, "rw").use { output ->\n                    output.seek(existing)\n                    val buffer = ByteArray(256 * 1024)\n                    body.byteStream().use { input ->\n                        while (!control.stopped.get()) {\n                            val read = input.read(buffer)\n                            if (read == -1) break\n                            if (!ensureNetworkPolicy(task.id, control)) break\n                            bandwidthLimiter.acquire(read)\n                            output.write(buffer, 0, read)\n                            downloaded += read\n                            val now = System.currentTimeMillis()\n                            if (now - lastTime >= 500L) {\n                                val speed = ((downloaded - lastBytes) * 1000L) / (now - lastTime).coerceAtLeast(1L)\n                                DownloadRepository.updateProgress(task.id, downloaded, total, speed, label)\n                                lastBytes = downloaded\n                                lastTime = now\n                                updateAggregateNotificationThrottled(now)\n                            }\n                        }\n                    }\n                }\n\n                if (!control.stopped.get() && total > 0L && target.length() < total) {\n                    throw IOException("$label quedó incompleto")\n                }\n            }\n        } finally {\n            control.calls.remove(call)\n        }\n    }\n\n    private fun ensureStagingSpace(target: File, total: Long) {\n        if (total <= 0L) return\n        val remaining = (total - target.length()).coerceAtLeast(0L)\n        val reserve = 32L * 1024L * 1024L\n        val usable = downloadsDirectory().usableSpace\n        if (usable in 0 until (remaining + reserve)) {\n            throw IOException("Espacio insuficiente para completar las pistas de video")\n        }\n    }'''
    )
    # Add staging helpers and cleanup.
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/download/DownloadService.kt",
        '''    private fun singleMetaFile(id: String): File = File(downloadsDirectory(), ".$id.singlemeta")\n\n    private fun cleanupHttpParts(id: String) {\n        runCatching { partialFile(id).delete() }''',
        '''    private fun singleMetaFile(id: String): File = File(downloadsDirectory(), ".$id.singlemeta")\n    private fun youtubeVideoFile(id: String): File = File(downloadsDirectory(), ".$id.yt-video.part")\n    private fun youtubeAudioFile(id: String): File = File(downloadsDirectory(), ".$id.yt-audio.part")\n    private fun youtubeMuxFile(id: String, container: String): File = File(downloadsDirectory(), ".$id.muxing.$container")\n\n    private fun cleanupHttpParts(id: String) {\n        runCatching { partialFile(id).delete() }\n        runCatching { youtubeVideoFile(id).delete() }\n        runCatching { youtubeAudioFile(id).delete() }\n        downloadsDirectory().listFiles()?.filter { it.name.startsWith(".$id.muxing.") }?.forEach { runCatching { it.delete() } }'''
    )

    # ------------------------------------------------------------------
    # Settings copy: reflect actual new capabilities, without claiming background clipboard access.
    # ------------------------------------------------------------------
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/SettingsScreen.kt",
        '''                "Video+audio combinado y audio-only pueden descargarse. Las pistas de alta calidad separadas se muestran, pero requieren un muxer para generar un archivo final con audio.",''',
        '''                "Video+audio combinado y audio-only pueden descargarse. Las pistas separadas compatibles de alta calidad se descargan y fusionan localmente con MediaMuxer para generar un archivo final con audio.",'''
    )
    replace_exact(
        root,
        "app/src/main/java/com/managerdownloader/app/ui/SettingsScreen.kt",
        '''        SettingsCard(title = "Adblock y privacidad") {''',
        '''        SettingsCard(title = "Portapapeles") {\n            Text(\n                "Cuando Manager Downloader recupera el foco, puede detectar URLs HTTP/HTTPS o magnet copiadas y pedir confirmación antes de abrirlas. Android 10+ no permite lectura permanente del portapapeles en segundo plano.",\n                color = MaterialTheme.colorScheme.onSurfaceVariant,\n                fontSize = 12.sp\n            )\n        }\n\n        SettingsCard(title = "Adblock y privacidad") {'''
    )

    # Copy new modules after patching existing files.
    copy_payload(bundle, root)

    # ------------------------------------------------------------------
    # Documentation: keep source-of-truth version and limitations explicit.
    # ------------------------------------------------------------------
    prepend_once(
        root,
        "CHANGELOG.md",
        "# Manager Downloader v0.8.0",
        '''# Manager Downloader v0.8.0\n\n## Auditoría aplicada\n- 8 parches de estabilidad del informe maestro v0.7.5 → v0.8.0.\n- HTTP cleartext habilitado deliberadamente para mirrors/NAS/trackers no TLS.\n- Importación segura de .torrent SAF y ACTION_VIEW HTTP/HTTPS hacia el navegador integrado.\n- Validación defensiva de TorrentHandle JNI.\n\n## Video\n- Alta calidad YouTube con pistas separadas de video+audio y fusión nativa MediaMuxer MP4/WebM sin recodificación.\n- URLs temporales de formatos HD se refrescan al comenzar el trabajo.\n- Playlists de YouTube se extraen con paginación y se encolan como trabajos JIT para no guardar URLs directas caducables.\n- Sniffer web intercepta fetch/XHR para HLS/DASH, permite rescaneo reactivo y analiza variantes de HLS Master.\n\n## Portapapeles\n- Detección únicamente cuando la app está en primer plano/con foco, respetando las restricciones de Android 10+. No se promete monitoreo global en background.\n\n## Compatibilidad\n- El modelo persistido añade solo campos opcionales; las colas v0.7.5 siguen cargando.\n- No se intenta eludir DRM, autenticación, contenido privado ni controles de acceso.'''
    )
    prepend_once(
        root,
        "MIGRATION_AUDIT.md",
        "# Auditoría aplicada — v0.8.0",
        '''# Auditoría aplicada — v0.8.0\n\nBase auditada: v0.7.5. Esta actualización conserva la arquitectura y los mecanismos de reanudación/AtomicFile/SafePowerManager existentes, y añade funciones mediante campos opcionales y módulos aislados. La compilación de GitHub Actions es obligatoria antes de hacer commit.\n\nDecisión deliberada: el monitor de portapapeles se limita al primer plano porque Android 10+ restringe la lectura del portapapeles en background. HLS Master se analiza y muestra por calidad, pero no se presenta un manifiesto como si fuera un archivo MP4 directo.'''
    )
    replace_exact(root, "README.md", "## v0.7.5", "## v0.8.0")

    print("v0.8.0 overlay applied successfully")


if __name__ == "__main__":
    main()
