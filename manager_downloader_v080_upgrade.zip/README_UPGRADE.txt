Manager Downloader v0.8.0 upgrade bundle
========================================

Base requerida: v0.7.5
Archivo de Action recomendado: .github/workflows/upgrade-v080.yml
ZIP esperado en la raíz del repositorio: manager_downloader_v080_upgrade.zip

Este ZIP es un overlay seguro: NO reemplaza el repositorio completo. La Action:
1) valida la base v0.7.5;
2) crea la rama de respaldo pre-v0.8.0 si no existe;
3) aplica apply_v080.py sobre la copia del runner;
4) ejecuta preflight y git diff --check;
5) compila :app:assembleDebug;
6) solo si compila hace commit/push a main y publica el APK.

Incluye:
- 8 parches de estabilidad del informe maestro.
- YouTube HD con video+audio separados y MediaMuxer nativo MP4/WebM.
- Resolución JIT para elementos de playlists de YouTube.
- Detección HLS/DASH vía fetch/XHR, rescaneo reactivo y análisis de variantes HLS Master.
- Detección de portapapeles únicamente cuando la app está en primer plano/con foco.

No intenta eludir DRM, autenticación, contenido privado ni controles de acceso.
