# 0.5.1

## Fixed
- Corrige error de compilación de Compose por imports faltantes de `Modifier.weight` en BrowserScreen, SettingsScreen y DownloadsScreen.

# Changelog

## 0.5.0 — Browser stabilization & professional controls

### Fixed
- Browser search/address bar now executes from the keyboard search action and the search button.
- Default search engine changed to DuckDuckGo for more reliable embedded-WebView searches; Google and Bing remain selectable.
- Better handling for links that open in a new window (`target=_blank`).
- Better handling of external/custom URL schemes instead of silently ignoring them.
- Main-frame browser network errors are shown with a retry action.

### Browser / Adblock
- One-tap adblock ON/OFF directly in the browser.
- Per-site allow-list (“Permitir este sitio”) for pages that break under blocking.
- Tracker blocking remains independently configurable.
- Expanded EasyList/EasyPrivacy host parsing for common `$third-party` / request-type rules.
- Session blocked-request counter.
- Optional Chrome-compatible User-Agent that removes the most obvious WebView marker; this is compatibility-oriented, not an “undetectable” promise.
- DOM media sniffer for HTTP/HTTPS video, audio, image and downloadable links, in addition to WebView request/download detection.
- DRM and `blob:` bypassing are intentionally not implemented.

### Downloads
- Search downloads by filename, URL or detail.
- Filters for active, paused, completed, errors and torrents.
- Refresh an expired HTTP URL without manually deleting existing resumable parts.
- Optional expected SHA-256 when creating a download; the completed file is validated before it is published.
- Existing automatic file categorization and SAF folder selection retained.

### Performance / network
- Global HTTP bandwidth limiter from 5–100 MB/s, or unlimited.
- Torrent session bandwidth limit follows the same global setting.
- Wi-Fi-only mode: active transfers are safely paused/re-queued when Wi-Fi disappears and can continue when Wi-Fi returns.
- Existing adaptive HTTP Range acceleration (up to 12 segments/file) retained.
- Existing sequential or parallel queue mode retained.

### UX
- Notification actions: Pause all / Resume.
- System, Light and Dark theme selection.
- Version bumped to 0.5.0.

### Planned after v0.5 is stable
- Reliable scheduler with WorkManager constraints.
- ZIP/7z/RAR extraction workflow.
- FTP/FTPS/SFTP transfer engines.
- HTTP/SOCKS proxy profiles and credential vault using Android Keystore.
- Foreground-only clipboard link detection (Android restricts background clipboard access).
- Optional encrypted vault / biometric gate.
- Home-screen progress widget.
