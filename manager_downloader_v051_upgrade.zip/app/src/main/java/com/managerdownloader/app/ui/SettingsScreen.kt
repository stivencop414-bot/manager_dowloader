package com.managerdownloader.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.managerdownloader.app.browser.ContentBlocker
import com.managerdownloader.app.data.QueueMode
import com.managerdownloader.app.data.SearchEngine
import com.managerdownloader.app.data.SettingsRepository
import com.managerdownloader.app.data.StorageRepository
import com.managerdownloader.app.data.ThemeMode

@Composable
fun SettingsScreen(
    contentPadding: PaddingValues,
    onTransferSettingsChanged: () -> Unit,
    onSelectDownloadFolder: () -> Unit
) {
    val settings by SettingsRepository.settings.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(
                start = 20.dp,
                end = 20.dp,
                top = contentPadding.calculateTopPadding() + 20.dp,
                bottom = contentPadding.calculateBottomPadding() + 24.dp
            ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "AJUSTES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.8.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("Manager Downloader", fontSize = 31.sp, fontWeight = FontWeight.Bold)
        Text(
            "Rendimiento, red, navegador, privacidad y apariencia.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )

        SettingsCard(title = "Almacenamiento y organización") {
            Text("Carpeta de destino", fontWeight = FontWeight.SemiBold)
            Text(
                StorageRepository.selectedLabel(),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            Text(
                "Los archivos terminados se ordenan en Videos, Imágenes, Audio, Comprimidos, Programas, Documentos, Torrents y Otros.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            OutlinedButton(onClick = onSelectDownloadFolder) {
                Text("Elegir / cambiar carpeta")
            }
        }

        SettingsCard(title = "Modo de cola") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = settings.queueMode == QueueMode.SEQUENTIAL,
                    onClick = {
                        SettingsRepository.setQueueMode(QueueMode.SEQUENTIAL)
                        onTransferSettingsChanged()
                    },
                    label = { Text("Uno por uno") }
                )
                FilterChip(
                    selected = settings.queueMode == QueueMode.PARALLEL,
                    onClick = {
                        SettingsRepository.setQueueMode(QueueMode.PARALLEL)
                        onTransferSettingsChanged()
                    },
                    label = { Text("Simultáneos") }
                )
            }

            if (settings.queueMode == QueueMode.PARALLEL) {
                Spacer(Modifier.height(10.dp))
                Text("Máximo simultáneo: ${settings.maxParallelDownloads}", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = settings.maxParallelDownloads.toFloat(),
                    onValueChange = { SettingsRepository.setMaxParallelDownloads(it.toInt()) },
                    onValueChangeFinished = onTransferSettingsChanged,
                    valueRange = 2f..6f,
                    steps = 3
                )
            }
        }

        SettingsCard(title = "Aceleración y ancho de banda") {
            Text("Conexiones por archivo: ${settings.segmentsPerFile}", fontWeight = FontWeight.SemiBold)
            Text(
                "Usa HTTP Range cuando el servidor lo permite. Para servidores que limitan una sola conexión, varios segmentos pueden aprovechar mejor el enlace.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            Slider(
                value = settings.segmentsPerFile.toFloat(),
                onValueChange = { SettingsRepository.setSegmentsPerFile(it.toInt()) },
                onValueChangeFinished = onTransferSettingsChanged,
                valueRange = 1f..12f,
                steps = 10
            )

            Spacer(Modifier.height(8.dp))
            Text(
                if (settings.bandwidthLimitMbps == 0) "Límite de velocidad: sin límite"
                else "Límite global: ${settings.bandwidthLimitMbps} MB/s",
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = settings.bandwidthLimitMbps.toFloat(),
                onValueChange = { SettingsRepository.setBandwidthLimitMbps((it / 5f).toInt() * 5) },
                onValueChangeFinished = onTransferSettingsChanged,
                valueRange = 0f..100f,
                steps = 19
            )
            ToggleRow(
                title = "Solo Wi‑Fi",
                subtitle = "Evita iniciar nuevas descargas HTTP o torrent usando datos móviles.",
                checked = settings.wifiOnly,
                onCheckedChange = {
                    SettingsRepository.setWifiOnly(it)
                    onTransferSettingsChanged()
                }
            )
        }

        SettingsCard(title = "Navegador") {
            Text("Motor de búsqueda", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = settings.searchEngine == SearchEngine.DUCKDUCKGO,
                    onClick = { SettingsRepository.setSearchEngine(SearchEngine.DUCKDUCKGO) },
                    label = { Text("DuckDuckGo") }
                )
                FilterChip(
                    selected = settings.searchEngine == SearchEngine.GOOGLE,
                    onClick = { SettingsRepository.setSearchEngine(SearchEngine.GOOGLE) },
                    label = { Text("Google") }
                )
            }
            FilterChip(
                selected = settings.searchEngine == SearchEngine.BING,
                onClick = { SettingsRepository.setSearchEngine(SearchEngine.BING) },
                label = { Text("Bing") }
            )

            ToggleRow(
                title = "Compatibilidad tipo Chrome",
                subtitle = "Reduce la identificación trivial del WebView usando un User‑Agent móvil más compatible. No oculta todas las señales del navegador.",
                checked = settings.chromeCompatUserAgent,
                onCheckedChange = SettingsRepository::setChromeCompatUserAgent
            )
            ToggleRow(
                title = "Detector de medios",
                subtitle = "Detecta enlaces HTTP/HTTPS de video, audio e imágenes visibles en la página y en el DOM.",
                checked = settings.mediaSnifferEnabled,
                onCheckedChange = SettingsRepository::setMediaSnifferEnabled
            )
        }

        SettingsCard(title = "Adblock y privacidad") {
            ToggleRow(
                title = "Bloquear publicidad",
                subtitle = "Se puede activar/desactivar también desde el navegador con el botón del escudo.",
                checked = settings.adBlockEnabled,
                onCheckedChange = SettingsRepository::setAdBlockEnabled
            )
            ToggleRow(
                title = "Bloquear rastreadores",
                subtitle = "Añade reglas de privacidad; desactívalo si una web deja de funcionar.",
                checked = settings.blockTrackers,
                enabled = settings.adBlockEnabled,
                onCheckedChange = SettingsRepository::setBlockTrackers
            )
            Text(
                "${ContentBlocker.ruleCount()} dominios · ${ContentBlocker.blockedCount()} peticiones bloqueadas en esta sesión",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
            )
            OutlinedButton(onClick = { ContentBlocker.refreshIfStale(force = true) }) {
                Text("Actualizar listas")
            }
        }

        SettingsCard(title = "Apariencia") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = settings.themeMode == ThemeMode.SYSTEM,
                    onClick = { SettingsRepository.setThemeMode(ThemeMode.SYSTEM) },
                    label = { Text("Sistema") }
                )
                FilterChip(
                    selected = settings.themeMode == ThemeMode.LIGHT,
                    onClick = { SettingsRepository.setThemeMode(ThemeMode.LIGHT) },
                    label = { Text("Claro") }
                )
                FilterChip(
                    selected = settings.themeMode == ThemeMode.DARK,
                    onClick = { SettingsRepository.setThemeMode(ThemeMode.DARK) },
                    label = { Text("Oscuro") }
                )
            }
        }

        Text(
            "Torrent: magnet, .torrent local y .torrent web usan libtorrent. Manager Downloader detiene la siembra al completar.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange
        )
    }
}
