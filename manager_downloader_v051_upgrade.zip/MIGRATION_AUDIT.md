# v0.5 implementation audit

The v0.5 cycle is intentionally stabilization-first after v0.4 testing exposed browser reliability issues.

## High-priority fixes implemented
- Search/address navigation and keyboard IME search.
- New-window navigation.
- Live adblock switch + site allow-list.
- More useful host-rule parsing without pretending to implement the entire ABP syntax.
- DOM media discovery for normal HTTP/HTTPS resources.
- Queue search/filtering and expired-link replacement.
- Wi-Fi-only policy, bandwidth limiting and optional SHA-256 verification.

## Deliberately not bundled into this stabilization release
FTP/FTPS/SFTP, archive extraction, scheduler, proxy profiles, credential vault, biometric private vault and widgets are separate subsystems. Shipping all of them in the same untested build would increase the regression surface substantially. They are scheduled after v0.5 has passed device testing.

## Platform constraints
- Android does not permit an ordinary app to bypass Doze/background limits indefinitely; the foreground service preserves resumable state and respects platform timeouts.
- Android 10+ restricts background clipboard access, so a future clipboard detector must be foreground/user-visible rather than a hidden monitor.
- There is no standard Android API that makes an arbitrary downloaded file “Play Protect verified”. Production trust requires a stable signing key and, ideally, Play distribution/reputation.
