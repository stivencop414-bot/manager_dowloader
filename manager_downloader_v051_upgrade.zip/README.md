# Manager Downloader v0.5.0

Native Android download manager built with Kotlin + Jetpack Compose.

## Current core
- HTTP/HTTPS accelerated downloads using adaptive Range segmentation (1–12 connections/file).
- Pause/resume with persistent partial segments, ETag/Last-Modified validation and URL refresh.
- Sequential or parallel queue modes (up to 6 simultaneous tasks).
- Global bandwidth limit and Wi-Fi-only mode.
- Magnet links, local `.torrent` files and remote `.torrent` URLs through jlibtorrent/libtorrent.
- User-selected download folder via Android Storage Access Framework.
- Automatic folders: Videos, Imagenes, Audio, Comprimidos, Programas, Documentos, Torrents and Otros.
- Smart duplicate renaming.
- Search and filters across the queue.
- Optional SHA-256 verification.
- Foreground download service and actionable notifications.

## Browser v0.5
- Search/address bar with keyboard search action.
- DuckDuckGo, Google or Bing search engine.
- Better new-window and custom-scheme handling.
- Adblock master toggle in browser and Settings.
- Tracker toggle plus per-site allow-list.
- EasyList/EasyPrivacy/hosts-based network rules.
- Request + DOM media detection for regular HTTP/HTTPS video/audio/images.
- Chrome-compatible UA option for site compatibility.

No browser can honestly guarantee that ad blocking or an embedded WebView is impossible to detect. Manager Downloader does not inject anti-anti-adblock spoofing, does not bypass DRM, and does not attempt to extract protected `blob:` media.

## Build
- namespace: `com.managerdownloader.app`
- minSdk: 26
- targetSdk: 36
- compileSdk: 36
- JDK: 17
- AGP: 9.3.0
- Gradle CI: 9.5.0
- Compose BOM: 2026.06.00

See `CHANGELOG.md` for version history.
