# Auditoría v0.7.2

Base confirmada: v0.7.1 en `main`, commit `ef1567758e3d32eb3974b4a71b4f4c17fe8365dd`.

Objetivo principal: corregir el cierre observado al entrar al navegador y aplicar las recomendaciones de estabilidad/sniffing del informe sin volver a introducir observadores permanentes ni cargas de memoria agresivas.

## Riesgos detectados en v0.7.1
- `WebView(context)` y varias configuraciones se ejecutaban directamente dentro del `AndroidView.factory`; una excepción del proveedor WebView podía propagarse a Compose.
- `onRenderProcessGone` destruía la vista pero no la retiraba explícitamente de su padre antes de recrearla.
- ContentBlocker podía leer/parsear listas grandes completas y mantener un conjunto de hosts mayor del necesario incluso en modo Estándar.
- El navegador no preservaba Referer al pasar un archivo detectado al motor HTTP.
- El sniffer previo era muy limitado para SPAs; reintroducir un MutationObserver permanente habría aumentado otra vez el riesgo de CPU/RAM.

## Decisiones v0.7.2
- Se usa un `FrameLayout` estable como host. La creación/configuración de WebView se encapsula en `runCatching`; si falla, el host permanece y Compose muestra un error recuperable.
- El renderer muerto se elimina del árbol de vistas antes de destruirse; la generación de WebView fuerza una recreación limpia y conserva la URL.
- El JavaScript sniffer es temporal (15 s), deduplicado y con máximo 40 elementos.
- HLS/DASH/blob se clasifican, pero no se convierten falsamente en archivos directos.
- Cookie/User-Agent/Referer viajan con la tarea y se persisten.
- Las listas de AdBlock se parsean en streaming y con topes de elementos para evitar picos de memoria.
- No se introduce Koin/Room en esta revisión: sería una migración transversal sin relación directa con el crash del navegador.

## Validación
- El workflow v0.7.2 compila `assembleDebug` antes de modificar `main`.
- Si la compilación falla, sube el log de Gradle como artifact `v072-build-log` y mantiene `main` intacto.
- Se crea una rama de respaldo `pre-v0.7.2` antes de aplicar la actualización.
