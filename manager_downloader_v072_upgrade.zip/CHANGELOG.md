# Manager Downloader v0.7.2

## Navegador: estabilidad y recuperación
- El WebView queda alojado dentro de un contenedor seguro: si Android System WebView/Chrome no puede crearse o configurarse, la pestaña muestra un error recuperable en lugar de cerrar toda la app.
- `onRenderProcessGone` retira la vista muerta de su padre, la destruye y recrea una instancia limpia conservando la URL actual.
- Limpieza defensiva al salir del navegador: se detiene la carga, se desconectan clientes y bridge JavaScript, se vacía la vista y se destruye sin propagar excepciones.
- Se habilita aceleración por hardware y manejo de cambios de configuración en `MainActivity` para reducir recreaciones completas por rotación/cambios de UI.
- La última URL del navegador se conserva mientras la app permanece abierta y se vuelve a cargar al regresar a la pestaña.
- La inicialización de ContentBlocker queda aislada para que un fallo en las listas no impida arrancar la app.

## Sniffer de medios más útil y acotado
- Detección por tres vías: `DownloadListener`, `shouldInterceptRequest` y un escaneo JavaScript temporal para reproductores dinámicos.
- El sniffer JavaScript tiene límite de 40 elementos y se desconecta automáticamente tras 15 segundos; no deja un `MutationObserver` permanente.
- Se ignoran fragmentos `.ts`, `.m4s`, `.cmfv` y `.cmfa` para evitar cientos de falsos resultados.
- HLS `.m3u8`, DASH `.mpd` y `blob:` se muestran como diagnóstico, pero no se envían al motor HTTP como si fueran archivos completos.
- Los archivos directos conservan Cookie, User-Agent y Referer; el Referer también se persiste en la cola y se aplica al reintentar/reanudar.
- YouTube continúa usando su extractor dedicado y no el sniffer genérico.

## Descargas múltiples desde el navegador
- Botón flotante con contador de elementos detectados.
- Hoja inferior con filtros: Todos, Descargables, Streams y Blob.
- Selección múltiple y envío de varios archivos directos a la cola en una sola acción.
- Streams/manifiestos y blobs quedan visibles para diagnóstico pero no son seleccionables como descarga directa.

## AdBlock y memoria
- Las listas se procesan como flujo de líneas en vez de cargar archivos completos gigantes en una sola cadena.
- Límites de memoria para EasyList, EasyPrivacy y hosts estrictos.
- La lista grande de hosts extra solo participa en modo Estricto; el modo Estándar mantiene un conjunto más pequeño.
- Se conserva la protección del documento principal y recursos esenciales para evitar páginas en blanco.

## Robustez general
- Se eliminan varios `!!` al cargar preferencias y los valores dañados vuelven a opciones seguras.
- Los cambios de ajustes no lanzan excepción si el repositorio aún no terminó de inicializar.
- Se mantiene el motor HTTP móvil de v0.7.1, máximo 8 conexiones, FileChannel/DirectBuffer, limitador dinámico, pausa/reanudación y perfil torrent conservador.

## Límites intencionales
- No se intenta eludir DRM, autenticación, contenido privado ni controles de acceso.
- Una URL `blob:` no contiene por sí misma un archivo HTTP recuperable fuera del contexto de la página.
- HLS/DASH se detectan, pero esta versión no descarga ni remuxa manifiestos como un video final.
