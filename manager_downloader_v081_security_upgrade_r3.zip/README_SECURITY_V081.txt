Manager Downloader v0.8.1 — Security + Stability + Throughput (R3)

R3 replaces the fragile text-anchor strategy that caused runs 33016949493 and 33017490936 to abort.
The workflow pins the Git blob hashes of every v0.8.0 source file it edits, performs resilient
source transformations, validates the entire resulting tree, compiles debug, and then compiles
release with R8 before publishing a candidate branch. main is never pushed directly.

R3 additional fixes:
- handles the actual DownloadService cooperative-pause block independent of indentation
- hardens all 3 NewPipe stream filters, including progressive video
- validates YouTube multi-range track URLs as public HTTPS
- candidate/preflight artifacts are optional on early failure
- source base is verified by Git blob SHA before any patch is attempted

The bundle contains source/config only and no executable upgrade script.
