# Manager Downloader v0.8.1 security release rules.
# Native bindings must keep their JNI-visible names.
-keep class com.frostwire.jlibtorrent.** { *; }
-dontwarn com.frostwire.jlibtorrent.**

# NewPipe uses reflection in portions of extractor metadata and service implementations.
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**

# Keep Android WebView bridge listener types referenced by platform callbacks.
-keepclassmembers class * implements androidx.webkit.WebViewCompat$WebMessageListener { *; }
