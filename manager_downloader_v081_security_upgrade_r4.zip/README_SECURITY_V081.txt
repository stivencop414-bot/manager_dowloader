Manager Downloader v0.8.1 — Security + Stability + Throughput (R4)

R4 is based on the R3 candidate that successfully passed every source patch and security preflight
in GitHub Actions run 33105906543. R4 fixes the two Kotlin compile causes exposed by that run:

- OkHttp Dns is implemented with an explicit object expression and override lookup(String).
- Regex source replacements are emitted literally so Kotlin backslashes such as '\n' are not
  reinterpreted by Python re.sub replacement processing.

R4 also adds generated-source integrity gates before Gradle compilation, migrates setup-java to v5,
keeps main protected from direct push, and still compiles Debug + Release/R8 before publishing a
candidate branch.

The bundle contains source/config only and no executable upgrade script.
