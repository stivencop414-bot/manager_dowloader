Manager Downloader v0.8.1 — Security + Stability + Throughput (R2)

R2 fixes the GitHub Actions patch anchor discovered in run 33016949493:
- YouTubeSupport.kt has 2 matching stream filters, not 3.
- Missing candidate diff artifacts no longer create a secondary failure after an earlier abort.

The bundle is source/configuration only. It contains no executable upgrade scripts.
The companion workflow verifies the bundle SHA-256 before copying any payload and keeps
all patch logic visible in the workflow for review.

Security hardening:
- disable global cleartext HTTP
- public HTTPS / SSRF policy for automatic remote clients
- bounded HLS/NewPipe responses
- scoped JitPack repository
- WebView WebMessageListener with origin/data validation
- R8 release gate
- no direct main push / no APK publication

Stability + throughput:
- cooperative HTTP pause (no interrupting FileChannel writers)
- startId-aware service stop race protection
- process-wide libtorrent SessionManager
- corrected Range probe
- resumable YouTube HD multi-range tracks
