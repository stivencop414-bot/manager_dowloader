Manager Downloader v0.8.1 — Security + Stability + Throughput (R5)

R5 is based on GitHub Actions run 33107012993.

R4 passed every source/security preflight, compileDebugKotlin and assembleDebug.
Its only failure was minifyReleaseWithR8.

R5 keeps R8 enabled and fixes the release-only Rhino/NewPipe dependency issue
without a global warning bypass. It adds the upstream NewPipe Rhino/JSR-223
rules plus exact suppressions for the five JVM-only java.beans classes reported
by that run: BeanDescriptor, BeanInfo, IntrospectionException, Introspector and
PropertyDescriptor.

The R5 workflow isolates minifyReleaseWithR8 as its own gate and uploads
missing_rules.txt/configuration.txt automatically if R8 fails again.

This ZIP contains source/config only and no executable upgrade script.
