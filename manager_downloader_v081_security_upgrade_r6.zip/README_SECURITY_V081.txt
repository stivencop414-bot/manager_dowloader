Manager Downloader v0.8.1 — Security + Stability + Throughput (R6)

R6 keeps the same reviewed application/source changes from R5.

Important correction:
GitHub Actions run 33108157553 did NOT fail because the R8 rules were missing.
The workflow preflight used:
    grep -Fq "$needle" "$file"
When a literal rule began with "-dontwarn" or "-keep", GNU grep interpreted
that text as command-line options. That produced false FAIL results and stopped
the job before Java/Android/Gradle setup or compilation.

R6 fixes the workflow validator by using:
    grep -Fq -- "$needle" "$file"
The "--" terminates grep option parsing, so patterns beginning with "-" are
treated as literal text.

The R8/NewPipe/Rhino rules from R5 remain unchanged. R6 still keeps R8 enabled,
does not use a global -ignorewarnings directive, and still captures
missing_rules.txt/configuration.txt if the real R8 stage later fails.

This ZIP contains source/config only and no executable upgrade script.
